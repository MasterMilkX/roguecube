
function Update () 
{
	var aniPlay = GetComponent("aniSprite");
	aniPlay.aniSprite (10,3,0,0,7,15);
}