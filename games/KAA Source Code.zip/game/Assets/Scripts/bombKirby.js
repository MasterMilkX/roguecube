//function aniSprite (columnSize, rowSize, colFrameStart, rowFrameStart, totalFrames, framesPerSecond) 

function Update ()
{
	var aniPlay = GetComponent("aniSprite");
	aniPlay.aniSprite (20,30,0,5,1,1);
}