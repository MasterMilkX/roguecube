var setBomb 		: boolean 	= true;
var detonation 		: int	  	= 3;
var blow 			: boolean 	= false;
private var	timer	: float		= 0.0;

function Update () 
{
	var aniPlay = GetComponent("aniSprite");

	Fuse();
	
	if (setBomb)
	{	
		aniPlay.aniSprite(3,1,1,0,1,1);
	}
	else
	{
		aniPlay.aniSprite(3,1,1,0,2,6);
	}
}
function Fuse ()
{
	setBomb = true;
	yield WaitForSeconds(detonation);
	setBomb = false;
	print ("Warning!");
	WaitForSeconds (2);
	print ("KABOOM!");
}
function Blow()
{
	if (blow)
	{
		print ("KABOOM!");
		//Destroy(this.gameObject);
	}
}