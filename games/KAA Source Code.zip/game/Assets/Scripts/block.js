var breakb : GameObject;

function Update () 
{
	if (breakb.GetComponent("break_block").killBlock == true)
	{
		Destroy(this.gameObject);
	}
}