
//Bomb Kirby Script

var walkSpeed   : float = 3.0;	
var runSpeed    : float = 5.0;
var slideSpeed	: float = 4.0;

var canSlide 	: boolean = false;
private var crouching 			: boolean = false;
private var counter				: float = 0.0;

var fallSpeed   : float = 1.0;
var walkJump    : float = 8.0;
var runJump		: float = 9.0;

var fly			: float = 10.0;
var canFly 		: boolean = true;
var flyFallSpeed: float = 0.25;

var gravity     : float = 20.0;
var startPos    : float = 0.0;
var moveDirection : int   = 1;

//running double key
private var ButtonCooler : float = 0.5 ; 																// Half a second before reset
private var ButtonCount : int = 0;
private var oneKeyPressed : boolean = false;

//flying key number
private var FlyCount 			: int = 0;
private var flyOneKeyPressed 	: boolean = false;
private var flyFalling			: boolean = false;

var velocity  : Vector3 = Vector3.zero;																	// speed of player and direction 

private var jumpEnabled 	: boolean 	= false;
private var runJumpEnabled 	: boolean 	= false;
private var flyEnabled		: boolean	= false;
private var falling			: boolean	= false;
private var jumpFall		: boolean	= false;

function Update()
{
	var aniPlay = GetComponent ( "aniSprite" );
	var controller : CharacterController = GetComponent(CharacterController );
	
	if( controller.isGrounded )												//if on ground
	{
		jumpEnabled = false;
		runJumpEnabled = false;
		jumpFall = false;
		falling = false;
		flyEnabled = false;
		flyFalling = false;
		crouching = false;
		slideTimerStarted = false;
		canFly = true;
		FlyCount = 0;
		startPos = transform.position.y;
		
		velocity = Vector3 ( Input.GetAxis ( "Horizontal" ), 0, 0 );
////////////////////////////////////////////////////////////////////////////////////
		if ( Input.GetKeyDown ("right" ) || Input.GetKeyDown ("left" ))		// allow double tapping
		{
	      	if ( ButtonCooler > 0 && ButtonCount == 1)
	      	{
	         	oneKeyPressed = false;
		    }
		    else
		    {
		      	ButtonCooler = 0.5 ; 
		        ButtonCount += 1 ;
		        oneKeyPressed = true;
		    }
		}
	   	if ( ButtonCooler > 0 )
	 	{
	   	   ButtonCooler -= 1 * Time.deltaTime ;
	  	}
	  	else
	  	{
	   	   ButtonCount = 0 ;
	   	}
////////////////////////////////////////////////////////////////
		if (velocity.x == 0 && moveDirection == 0 )			//idle right			
		{
			aniPlay.aniSprite (24,26,0,0.35,2,1); 
		}
		if (velocity.x == 0 && moveDirection == 1 )			//idle left				
		{
			aniPlay.aniSprite (24,26,0,13.25,2,1);
		}
		if (velocity.x < 0 && oneKeyPressed ) 				//walk right			
		{
			aniPlay.aniSprite (24,26,0,1.75,12,15);
			velocity.x *= walkSpeed;
		}
		if (velocity.x < 0 && !oneKeyPressed ) 				//run right			
		{
			aniPlay.aniSprite (24,26,1,3.25,7,15);
			velocity.x *= runSpeed;
		}
		if (velocity.x > 0 && oneKeyPressed) 				//walk left				
		{
			aniPlay.aniSprite (24,26,0,14.6,12,15);
			velocity.x *= walkSpeed;
		}
		if (velocity.x > 0 && !oneKeyPressed) 				//run left				
		{
			aniPlay.aniSprite (24,26,0,16.1,7,15);
			velocity.x *= runSpeed;
		}
		if ( Input.GetAxis ( "Vertical" ) < 0 )				//crouch
		{
			if (moveDirection == 0)							//crouch right
			{
				velocity.x = 0;								//keep player from moving
				aniPlay.aniSprite (24,26,3,0.35,1,1); 
				crouching = true;
			}
			if (moveDirection == 1)							//crouch left
			{
				velocity.x = 0;								//keep player from moving
				aniPlay.aniSprite (24,26,3,13.25,1,1);
				crouching = true;
			}
		}
///Jumps
		if ( Input.GetButtonDown( "Jump" ) && oneKeyPressed)		//walking jump
		{
			velocity.y = walkJump;
			jumpEnabled = true;
		}
		if (Input.GetButtonDown("Jump") && !oneKeyPressed )			// running jump
		{
			velocity.y = runJump;
			runJumpEnabled = true;
		}
///Slide
		if ( ( Input.GetButtonDown("Jump") )&& crouching && !canSlide)	//can slide after key press
		{
			canSlide = true;			
		}
		if (canSlide)
		{
			Slide();
			counter += Time.deltaTime;
			if (counter >= 0.5)
			{
				canSlide = false;
				counter = 0;
			}
		}
	}



//In air	
	if ( !controller.isGrounded)									// not on ground
	{
		velocity.x = Input.GetAxis ( "Horizontal" );

		if ( Input.GetButtonDown("Jump") && FlyCount < 6 && canFly)
		{
			FlyCount += 1;
			velocity.y = fly;
			velocity.y += fly;
		}
		if ( FlyCount == 5 )
		{
			FlyCount = 0;
			canFly = false;
		}

		if ( !jumpEnabled && !runJumpEnabled && !jumpFall) 	// fall off edge
		{
			falling = true;
		}
		if (Input.GetButtonUp ( "Jump" ) && canFly)									//jump controlled height
		{
			velocity.y = velocity.y - fallSpeed; 							//subtract current height from 1 if jump button is up
			jumpFall = true;
		}
		if ( moveDirection == 1 )											//left jump
		{
			if ( jumpEnabled )												//regular jump
			{
				velocity.x *= walkSpeed;
				aniPlay.aniSprite (24,26,0,17.45,10,15);
			}
			if ( runJumpEnabled )											//run jump
			{
				velocity.x *= runSpeed;
				aniPlay.aniSprite (24,26,0,17.45,10,15);
			}
		}
		if ( moveDirection == 0 )											//right jump
		{
			if ( jumpEnabled )												// walking jump
			{
				velocity.x *= walkSpeed;
				aniPlay.aniSprite (24,26,0,4.6,10,15);
			}
			if ( runJumpEnabled )											//run jump
			{
				velocity.x *= runSpeed;
				aniPlay.aniSprite (24,26,0,4.6,10,15);
			}
		}
		if ( falling )														//fall sequence
		{
			if ( moveDirection == 0 )										// right fall
			{
				velocity.x *= walkSpeed;
				aniPlay.aniSprite (24,26,8,4.6,2,15);
			}
			if ( moveDirection == 1 )										// left fall
			{
				velocity.x *= walkSpeed;
				aniPlay.aniSprite (24,26,8,17.45,2,15);
			}
		}
		if ( FlyCount > 0 && FlyCount < 5 )
		{
			Fly();
		}
		if ( FlyCount == 5 && !canFly && jumpFall)
		{
			if (moveDirection == 0) //fly right
			{
				aniPlay.aniSprite (24,24,17,3.25,4,12);
			}
			if (moveDirection == 1) //fly left
			{
				aniPlay.aniSprite (24,26,17,16.1,4,12);
			}
		}
	}
	if ( velocity.x < 0 )													//get last move direction - left
	{
		moveDirection = 0;													//set moveDirection to left
	}
	if ( velocity.x > 0)													//get last move direction - right
	{
		moveDirection = 1;													//set moveDirection to right
	}
	
	velocity.y -= gravity * Time.deltaTime;//apply gravity
	controller.Move ( velocity * Time.deltaTime );//move the controller
}

function Slide ()
{
	if (canSlide)
	{
		var aniPlay = GetComponent ( "aniSprite" );
		velocity = Vector3 ( Input.GetAxis ( "Horizontal" ), 0, 0 );
		
		if (moveDirection == 0)		//slide right
		{
			velocity.x = -slideSpeed;
			aniPlay.aniSprite (24,26,6,0.35,1,1); 
		}
		if (moveDirection == 1)		//slide left
		{
			velocity.x = slideSpeed;
			aniPlay.aniSprite (24,26,6,13.25,1,1);
		}
	}
}
function Fly ()
{
	var aniPlay = GetComponent ( "aniSprite" );
	
	if (moveDirection == 0) //fly right
	{
		aniPlay.aniSprite (24,24,17,1.5,6,12);
	}
	if (moveDirection == 1) //fly left
	{
		aniPlay.aniSprite (24,26,17,14.5,6,12);
	}
}
function OnTriggerEnter ( other : Collider )
{
	if ( other.gameObject.tag == "break_block" ) 
	{
		if (canSlide)
		{
			other.collider.isTrigger = true;
		}
	}
}