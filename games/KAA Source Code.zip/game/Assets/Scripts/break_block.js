var killBlock : boolean = false;

function OnTriggerEnter ( other : Collider )
{
	if (other.gameObject.tag == "Player")
	{
		var slide = other.GetComponent("bomb_kirby_controls");
		
		if (slide.canSlide)
		{
			Kill();
		}
	}
}

function Kill ()
{
	killBlock = true;
}